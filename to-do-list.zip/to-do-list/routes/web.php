<?php

Route::resource('task', 'TasksController');

Route::get('/', function () {
    return redirect()->route('task.index');
});
