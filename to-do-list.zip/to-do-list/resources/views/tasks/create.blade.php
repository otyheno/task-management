@extends('layouts.main')
@section('title')
    Create New
@endsection
@section('content')

    <div class="row">
        <div class="col-sm-12">
            <h1>Create Task</h1>
            {!! Form::open(['route'=>'task.store', 'method'=>'POST']) !!}
            @component('components.taskForm')
            @endcomponent
            {!! Form::close() !!}
        </div>
    </div>

@endsection
