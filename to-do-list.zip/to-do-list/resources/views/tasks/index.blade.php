@extends('layouts.main')
@section('title')
    Home
@endsection
@section('content')

<div class="row justify-content-center mb-3">
    <div class="col-sm-4">
    <a href="{{ route('task.create')}}" class="btn btn-block btn-success">Create task</a>
    </div>
</div>

@if ($tasks->count()==0)
<p class="lead mt-100" style="text-align: center;">No tasks. Click create to add new task</p>
@else
@foreach ($tasks as $task)
    <div class="row ">
        <div class="col-sm-12">
            <h3>Name: {{$task->name}}</h3>
            <small>Date Created: {{ $task->created_at }}</small>

            <p>Description: {{ $task->description }}</p>
            <h4>Due Date: {{ $task->due_date }}</h4>

            {!! Form::open([ 'route' => ['task.destroy', $task->id], 'method'=>'DELETE']) !!}
            <a href="{{ route('task.edit', $task->id)}}" class="btn btn-sm btn-info">Edit</a>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            {!! Form::close() !!}
        </div>
    </div>
    <hr>
@endforeach
@endif
<div class="row justify-content-center">
    <div class="col-sm-6 text-center">
        {{ $tasks->links()}}
    </div>
</div>

@endsection
