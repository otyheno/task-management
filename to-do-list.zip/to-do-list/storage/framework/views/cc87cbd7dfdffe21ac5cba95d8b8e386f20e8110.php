

    <?php echo e(Form::label('name', 'Task Name', ['class' => 'control-label'])); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control form-control-lg', 'placeholder' => 'Task Name'])); ?>


    <?php echo e(Form::label('description', 'Task Description', ['class' => 'control-label mt-3'])); ?>

    <?php echo e(Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => 'Task Description'])); ?>


    <?php echo e(Form::label('due_date', 'Due Date', ['class' => 'control-label mt-3'])); ?>

    <?php echo e(Form::date('due_date', null, ['class' => 'form-control col-sm-3 '])); ?>


    <div class="row justify-content-center mt-3">
        <div class="col-sm-4">
        <a href="<?php echo e(route('task.index')); ?>" class="btn btn-block btn-secondary">Back</a>
        </div>
        <div class="col-sm-4">
            <button class="btn btn-block btn-primary" type="submit">Save</button>
        </div>
    </div>


<?php /**PATH D:\xampp\htdocs\to-do-list\resources\views/components/taskForm.blade.php ENDPATH**/ ?>