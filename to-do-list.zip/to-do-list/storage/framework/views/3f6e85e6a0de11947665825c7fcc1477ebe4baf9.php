<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="row justify-content-center mb-3">
    <div class="col-sm-4">
    <a href="<?php echo e(route('task.create')); ?>" class="btn btn-block btn-success">Create task</a>
    </div>
</div>

<?php if($tasks->count()==0): ?>
<p class="lead mt-100" style="text-align: center;">No tasks. Click create to add new task</p>
<?php else: ?>
<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row ">
        <div class="col-sm-12">
            <h3>Name: <?php echo e($task->name); ?></h3>
            <small>Date Created: <?php echo e($task->created_at); ?></small>

            <p>Description: <?php echo e($task->description); ?></p>
            <h4>Due Date: <?php echo e($task->due_date); ?></h4>

            <?php echo Form::open([ 'route' => ['task.destroy', $task->id], 'method'=>'DELETE']); ?>

            <a href="<?php echo e(route('task.edit', $task->id)); ?>" class="btn btn-sm btn-info">Edit</a>
            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
            <?php echo Form::close(); ?>

        </div>
    </div>
    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class="row justify-content-center">
    <div class="col-sm-6 text-center">
        <?php echo e($tasks->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\to-do-list\resources\views/tasks/index.blade.php ENDPATH**/ ?>