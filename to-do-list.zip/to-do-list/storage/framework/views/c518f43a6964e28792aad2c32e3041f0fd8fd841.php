<?php $__env->startSection('title'); ?>
    Create New
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-12">
            <h1>Create Task</h1>
            <?php echo Form::open(['route'=>'task.store', 'method'=>'POST']); ?>

            <?php $__env->startComponent('components.taskForm'); ?>
            <?php echo $__env->renderComponent(); ?>
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\to-do-list\resources\views/tasks/create.blade.php ENDPATH**/ ?>