<?php $__env->startSection('title'); ?>
    Edit Task
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-sm-12">
            <h1>Edit Task</h1>
            <?php echo Form::model($task, ['route'=>['task.update', $task->id], 'method'=>'PUT']); ?>

            <?php $__env->startComponent('components.taskForm'); ?>
            <?php echo $__env->renderComponent(); ?>
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\to-do-list\resources\views/tasks/edit.blade.php ENDPATH**/ ?>